package cn.edu.cdu.ftsoft.test;

import java.sql.Connection;
import java.sql.PreparedStatement;

import org.junit.Test;

import cn.edu.cdu.ftsoft.util.C3P0Util;

public class TestC3P0 {
	
	@Test
	public void testInsert(){
		Connection conn = null;
		PreparedStatement ps = null;
		
		try {
			conn = C3P0Util.getConnection();
			System.out.println("******"+conn);
			ps = conn.prepareStatement("insert into account(name,money) values('xxx',2000)");
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			C3P0Util.release(conn, ps, null);
			
		}
		
		
		System.out.println(conn.getClass().getName());
	}
}
