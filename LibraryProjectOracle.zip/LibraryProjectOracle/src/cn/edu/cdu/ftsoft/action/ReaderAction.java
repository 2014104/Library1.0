package cn.edu.cdu.ftsoft.action;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import cn.edu.cdu.ftsoft.dao.LendDao;
import cn.edu.cdu.ftsoft.dao.ReaderDao;
import cn.edu.cdu.ftsoft.daoImpl.LendDaoImpl;
import cn.edu.cdu.ftsoft.daoImpl.ReaderDaoImpl;
import cn.edu.cdu.ftsoft.model.Book;
import cn.edu.cdu.ftsoft.model.Reader;
import cn.edu.cdu.ftsoft.util.Pager;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
public class ReaderAction extends ActionSupport{
	    private ReaderDaoImpl readerDao=new ReaderDao();
		private String message;
		private int pageNow=1;   				 //��ʼҳ��Ϊ��һҳ
		private int pageSize=4;   				 //ÿҳ��ʾ4����¼
		private String minCnum;
		private String maxCnum;
		private String minPrice;
		private String maxPrice;
		private Reader reader;
		private String readerId; //ɾ�����޸�ͼ����ϢҪ�õ��������ֵ
		public String readerList() throws Exception{
			List readerList=readerDao.selectAllReader(pageNow,pageSize);
			Map request=(Map) ActionContext.getContext().get("request");
			Pager page=new Pager(pageNow,readerDao.selectReaderSize());
			request.put("bookList", readerList);
			request.put("page", page);
			return "readerManage";
		}
		public String addReader() throws Exception{
			Reader bo=readerDao.checkByReaderId(reader.getReaderId());
			if(bo!=null){              	 	//�ж�Ҫ���ӵĶ����Ƿ��Ѿ�����
				this.setMessage("�ö����Ѿ����ڣ�");
				return "readerManage";
			}
			readerDao.addReader(reader);
			this.setMessage("���ӳɹ���");
			return "readerManage";
		}
		public String selectOneReader(){
			Reader reader=readerDao.checkByReaderId(readerId);
			Map request=(Map) ActionContext.getContext().get("request");
			request.put("reader",reader);
			return "edit";
		}
		public String deleteReader(){
			LendDaoImpl lendDao=new LendDao();
			if(lendDao.selectByReaderId(readerId)!=null){
				this.setMessage("�ö����Ѿ�������,����ɾ�����뻹���ɾ��");
				return "readerManage";
			}
			readerDao.deleteByReaderId(readerId);
			this.setMessage("ɾ���ɹ���");
			return "readerManage";
		}

		public String selectPointReader() throws Exception{
			List readerList=readerDao.selectReaders(reader.getReaderId(),reader.getName(),minCnum,maxCnum,minPrice,maxPrice);
			//System.out.println("******"+book.getBookId()+","+book.getBookName()+","+book.getTypeName());
			if(readerList==null){
				this.setMessage("�����ڸö���");
				return "readerManage";
			}
			Map request=(Map) ActionContext.getContext().get("request");
			if(message!=null){
				request.put("message", message);
			}
			request.put("bookList", readerList);
			return "readerManage";
		}
		
		public String selectOneBook() throws Exception{
			Reader reader=readerDao.checkByReaderId(readerId);
			Map request=(Map) ActionContext.getContext().get("request");
			request.put("reader", reader);
			return "edit";
		}

		public String updateReader() throws Exception{
			readerDao.updateReaderTwo(reader);
			this.setMessage("�޸ĳɹ���");
			return "readerManage";
		}
		public String getMessage(){
			return this.message;
		}
		public void setMessage(String message){
			this.message = message;
		}
		
		
		public int getPageNow() {
			return pageNow;
		}
		public void setPageNow(int pageNow) {
			this.pageNow = pageNow;
		}
		public int getPageSize() {
			return pageSize;
		}
		public void setPageSize(int pageSize) {
			this.pageSize = pageSize;
		}
		
		public String getMinCnum() {
			return minCnum;
		}
		public void setMinCnum(String minCnum) {
			this.minCnum = minCnum;
		}
		public String getMaxCnum() {
			return maxCnum;
		}
		public void setMaxCnum(String maxCnum) {
			this.maxCnum = maxCnum;
		}
		public String getMinPrice() {
			return minPrice;
		}
		public void setMinPrice(String minPrice) {
			this.minPrice = minPrice;
		}
		public String getMaxPrice() {
			return maxPrice;
		}
		public void setMaxPrice(String maxPrice) {
			this.maxPrice = maxPrice;
		}
		public Reader getReader() {
			return reader;
		}
		public void setReader(Reader reader) {
			this.reader = reader;
		}
		public String getReaderId() {
			return readerId;
		}
		public void setReaderId(String readerId) {
			this.readerId = readerId;
		}
}
