package cn.edu.cdu.ftsoft.interceptor;

import java.io.PrintWriter;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;






import cn.edu.cdu.ftsoft.model.Reader;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

public class LoginInterceptor extends AbstractInterceptor {

	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		ActionContext ctx = invocation.getInvocationContext();  
        Map session = ctx.getSession();
        Reader stu=(Reader)session.get("stu");
        if(stu!=null){
        	return invocation.invoke();
        }else{
        	return "input";
        }
        
	}

}
