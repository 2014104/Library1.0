package cn.edu.cdu.ftsoft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;








import cn.edu.cdu.ftsoft.daoImpl.ReaderDaoImpl;
import cn.edu.cdu.ftsoft.model.Book;
import cn.edu.cdu.ftsoft.model.Reader;
import cn.edu.cdu.ftsoft.util.C3P0Util;

public class ReaderDao implements ReaderDaoImpl {
	PreparedStatement ps = null;
	ResultSet rs = null;
	Connection conn=null;
	
	public void addReader(Reader c) {
		try {
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement("insert into reader values(?,?,0,?,?,?,?,?,?,?,?,?)");
			ps.setString(1, c.getReaderId());
			ps.setString(2, c.getPassword());
			ps.setString(3, c.getName());
			ps.setString(4, c.getSex());
			ps.setDate(5, (java.sql.Date) c.getBorn());
			ps.setString(6, c.getPhoto());
			ps.setString(7, c.getPlace());
			ps.setString(8, c.getEmail());
			ps.setString(9, c.getTelephoto());
			ps.setInt(10,c.getNum());
			ps.setFloat(11,c.getPriceFine());
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			C3P0Util.release(conn, ps, null);
		}
		
	}

	public void updateReader(Reader stu) {
		conn = C3P0Util.getConnection();
		try {
			ps = conn.prepareStatement("update reader set num=? where readerId=?");
			ps.setInt(1, stu.getNum());
			ps.setString(2, stu.getReaderId());
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			C3P0Util.release(conn, ps, null);
		}
	}

	public List<Reader> listReader() {
		conn = C3P0Util.getConnection();
		String sql = "select * from student";
		try {
		ps = conn.prepareStatement(sql);
		List<Reader> StuList = new ArrayList<Reader>();
		    rs = ps.executeQuery();
			Reader c = null;
			while (rs.next()) {
				c = new Reader();
				StuList.add(c);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
			C3P0Util.release(conn, ps, rs);
		}
		return null;
	}

	public Reader checkByReaderId(String readerId) {
		conn = C3P0Util.getConnection();
		String sql = "select * from reader where readerId=?";
		Reader stu = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, readerId);
			ResultSet rs = ps.executeQuery();
			if (rs.next()) {
				stu=new Reader();
				stu.setReaderId(rs.getString(1));
				stu.setPassword(rs.getString(2));
				stu.setRole(rs.getInt(3));
				stu.setName(rs.getString(4));
				stu.setSex(rs.getString(5));
				stu.setBorn(rs.getDate(6));
				stu.setPhoto(rs.getString(7));
				stu.setPlace(rs.getString(8));
				stu.setEmail(rs.getString(9));
				stu.setTelephoto(rs.getString(10));
				stu.setNum(rs.getInt(11));
				stu.setPriceFine(rs.getFloat(12));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
						C3P0Util.release(conn, ps, null);
			
		}
		return stu;

	}

	public void deleteByReaderId(String readerId) {
		conn = C3P0Util.getConnection();
		String sql = "delete from reader where readerId = ?";
		try {
		    ps = conn.prepareStatement(sql);
			ps.setString(1, readerId);
			ps.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}finally {
			C3P0Util.release(conn, ps, null);
		}
		
	}

	public void updatePassword(String readerId, String password) {
		conn = C3P0Util.getConnection();
		String sql = "update student set password = ? where readerId = ?";
		try {
		    ps = conn.prepareStatement(sql);
			ps.setString(1, password);
			ps.setString(2, readerId);
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}finally {
			C3P0Util.release(conn, ps, null);
		}
		
	}

	/*
	 * public static void main(String[] args){ System.out.print("xxx");
	 * DB.createConn(); }
	 */

	public Reader checkByReaderIdPas(String readerId, String password) {
		conn = C3P0Util.getConnection();
		String sql = "select readerId,password,role from reader where readerId=? and password=?";
		Reader stu = null;
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, readerId);
			ps.setString(2, password);
			rs = ps.executeQuery();
			if (rs.next()) {
				stu = new Reader();
				stu.setReaderId(rs.getString("readerId"));
				stu.setPassword(rs.getString("password"));
				stu.setRole(rs.getInt("role"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
		return stu;
	}

	public List selectAllReader(int pageNow, int pageSize) {
		try {
			List list = new ArrayList();
			conn = C3P0Util.getConnection();
			String sql = "select * from ( select  t.*, rownum RN from reader t ) where RN > ? and RN <= ?";
			ps = conn.prepareStatement(sql);
			int pageSum=(pageNow - 1) * pageSize;
			ps.setInt(1, pageSum);
			ps.setInt(2, pageSum+pageSize);
			rs = ps.executeQuery();
			while (rs.next()) {
				Reader reader = new Reader();
				reader.setReaderId(rs.getString("readerId"));
				reader.setName(rs.getString("name"));
				reader.setBorn(rs.getDate("born"));
				reader.setSex(rs.getString("sex"));
				reader.setPlace(rs.getString("place"));
				reader.setEmail(rs.getString("email"));
				reader.setNum(rs.getInt("Num"));
				reader.setPriceFine(rs.getFloat("priceFine"));
				list.add(reader);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
	}

	public int selectReaderSize() {
		try {
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement("select count(*) from reader");	
			rs = ps.executeQuery();
			if (rs.next()) {
				int pageCount = rs.getInt(1);
				return pageCount;
			}
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
	}

	public List selectReaders(String readerId, String name,String minCnum, String maxCnum, String minPrice, String maxPrice) {
		String sql = "select * from reader where 1=1";
		List list = new ArrayList();
		if(!"".equals(readerId.trim())){
			sql+=" and readerId like ?"; //  ��������д%   %'1002'%
			list.add("%"+readerId.trim()+"%");// '%1002%'
		}
		
		if(!"".equals(name.trim())){
			sql+=" and name like ?";
			list.add("%"+name.trim()+"%");
		}
		
		if(!"".equals(minCnum.trim())){
			sql+=" and num>?";
			list.add(minCnum);
		}
		if(!"".equals(maxCnum.trim())){
			sql+=" and num< ?";
			list.add(maxCnum);
		}
		if(!"".equals(minPrice.trim())){
			sql+=" and priceFine>?";
			list.add(minPrice.trim());
		}
		if(!"".equals(maxPrice.trim())){
			sql+=" and priceFine< ?";
			list.add(maxPrice);
		}
		try {
			List bookList=new ArrayList();
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement(sql);
			//System.out.println("sql="+sql);
			for(byte i=0;i<list.size();i++){   //i���ֵΪlist.size(),�϶�������127,�����byte�ֽڿ��Խ�ʡ�ڴ棬���˲������ʵ�ʱ��
				ps.setString(i+1,(String) list.get(i));
			}
			rs=ps.executeQuery();
			while (rs.next()) {
				Reader reader = new Reader();
				reader.setReaderId(rs.getString("readerId"));
				reader.setName(rs.getString("name"));
				reader.setBorn(rs.getDate("born"));
				reader.setSex(rs.getString("sex"));
				reader.setPlace(rs.getString("place"));
				reader.setEmail(rs.getString("email"));
				reader.setNum(rs.getInt("Num"));
				reader.setPriceFine(rs.getFloat("priceFine"));
				bookList.add(reader);
			}
			return bookList;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
		
	}

	public void updateReaderTwo(Reader c) {
		try {
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement("update reader set password=?,name=?,sex=?,place=?,email=?,telephone=?,num=?,priceFine=? where readerId=?");
			ps.setString(1, c.getPassword());
			ps.setString(2, c.getName());
			ps.setString(3, c.getSex());
			ps.setString(4, c.getPlace());
			ps.setString(5, c.getEmail());
			ps.setString(6, c.getTelephoto());
			ps.setInt(7,c.getNum());
			ps.setFloat(8,c.getPriceFine());
			ps.setString(9,c.getReaderId());
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			C3P0Util.release(conn, ps, null);
		}
		
	}
}
