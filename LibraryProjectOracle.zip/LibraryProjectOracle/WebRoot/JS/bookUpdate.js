    function addBook() {
		window.location.href = "addBook.jsp";
	}