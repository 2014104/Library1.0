    function addReader() {
		window.location.href = "addReader.jsp";
	}