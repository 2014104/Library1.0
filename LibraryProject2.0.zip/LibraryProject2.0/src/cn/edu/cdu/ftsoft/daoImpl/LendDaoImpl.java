package cn.edu.cdu.ftsoft.daoImpl;

import java.util.List;

import cn.edu.cdu.ftsoft.model.Lend;

public interface LendDaoImpl {
	public List selectLend(String readerId,int pageNow,int pageSize);
	public int selectLendSize(String readerId);
	public Lend selectByBookId(String bookId);
	public boolean addLend(Lend lend);
	public Lend selectByBookISBN(String ISBN);
	public Lend selectByReaderId(String readerId);
	public boolean deleteLend(Lend l);
}
