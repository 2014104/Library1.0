package cn.edu.cdu.ftsoft.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import cn.edu.cdu.ftsoft.dao.ReaderDao;
import cn.edu.cdu.ftsoft.daoImpl.ReaderDaoImpl;
import cn.edu.cdu.ftsoft.model.Book;
import cn.edu.cdu.ftsoft.model.Reader;

public class ReaderDaoTest {

	//@Test
	public void testCheckByReaderIdPas() {
		ReaderDao rd=new ReaderDao();
		try {
			Reader re=rd.checkByReaderIdPas("0006", "11");
			System.out.print(re.getPassword());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
		public void testSelectReaders() {
			ReaderDao rd=new ReaderDao();
			try {
				List re=rd.selectReaders("000", "wang", "", "", "", "");
				if(re==null){
					return;
				}
				for(int i=0;i<re.size();i++){
					Reader b=(Reader) re.get(i);
					System.out.println(b.getReaderId()+","+b.getName()+","+b.getPriceFine());
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	//@Test
			public void testUpdateReaderTwo() {
				ReaderDao rd=new ReaderDao();
				try {
					Reader r=new Reader();
					r.setReaderId("11111");
					r.setPassword("11xxx");
					rd.updateReaderTwo(r);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
	//@Test
		public void testAddReader() {
			ReaderDao rd=new ReaderDao();
			try {
				Reader r=new Reader();
				r.setReaderId("111222");
				r.setPassword("11");
				rd.addReader(r);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	//@Test
		public void testDeleteByReaderId() {
			ReaderDaoImpl rd=new ReaderDao();
			try {
				rd.deleteByReaderId("2200");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	//@Test
	public void testCheckByReaderId() {
		ReaderDao rd=new ReaderDao();
		try {
			Reader re=rd.checkByReaderId("0006");
			System.out.print(re.getPassword()+","+re.getName()+","+re.getNum());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//@Test
	public void testUpdateReader() {
		ReaderDao rd=new ReaderDao();
		Reader r=new Reader();
		r.setNum(1);
		r.setReaderId("0006");
		try {
			rd.updateReader(r);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//@Test
	public void testSelectAllReader() {
		ReaderDaoImpl bd=new ReaderDao();
		try {
			List re=bd.selectAllReader(2, 3);
			System.out.println("��������="+bd.selectReaderSize());
			for(int i=0;i<re.size();i++){
				Reader b=(Reader) re.get(i);
				System.out.println(b.getReaderId()+","+b.getName());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
