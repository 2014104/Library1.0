package cn.edu.cdu.ftsoft.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import cn.edu.cdu.ftsoft.daoImpl.LendDaoImpl;
import cn.edu.cdu.ftsoft.model.Lend;
import cn.edu.cdu.ftsoft.util.C3P0Util;

public class LendDao implements LendDaoImpl{
	PreparedStatement ps = null;
	ResultSet rs = null;
	Connection conn=null;


	public List selectLend(String readerId, int pageNow, int pageSize) {
		try {
			List list = new ArrayList();
			conn = C3P0Util.getConnection();
			String sql="select l.bookId,b.ISBN,b.bookName,b.publisher,b.price,l.ITime from lend l,book b where l.bookId=b.bookId and readerId=? limit ?,?";
			ps = conn.prepareStatement(sql);
			ps.setString(1,readerId);
			ps.setInt(2,(pageNow-1)*pageSize);
			ps.setInt(3,pageSize);
			rs = ps.executeQuery();
			while (rs.next()) {
				Lend lend = new Lend();
				lend.setBookId(rs.getString("bookId"));
				lend.setISBN(rs.getString("ISBN"));
				lend.setBookName(rs.getString("bookName"));
				lend.setPublisher(rs.getString("publisher"));
				lend.setPrice(rs.getFloat("price"));
				lend.setITime(rs.getDate("ITime"));
				list.add(lend);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
	}

	public int selectLendSize(String readerId) {
		try {
			conn = C3P0Util.getConnection();
		    ps = conn.prepareStatement("select count(*) from lend where readerId=?");
			ps.setString(1, readerId);
			rs = ps.executeQuery();
			if (rs.next()) {
				int pageCount = rs.getInt(1);
				return pageCount;
			}
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
	}

	public Lend selectByBookId(String bookId) {
		try {
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement("select * from lend where bookId=?");
			ps.setString(1, bookId);
			rs = ps.executeQuery();
			if (rs.next()) {
				Lend lend = new Lend();
				lend.setBookId(rs.getString(1));
				lend.setReaderId(rs.getString(2));
				lend.setISBN(rs.getString(3));
				lend.setITime(rs.getDate(4));
				return lend;
			} else
				return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
	}

	//���ӽ��ļ�¼
	public boolean addLend(Lend lend) {
		try {
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement("insert into lend(bookId,readerId) values(?,?)");
			ps.setString(1, lend.getBookId());
			ps.setString(2, lend.getReaderId());
			ps.execute();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
	}

	
	//ɾ�����ļ�¼
	public boolean deleteLend(Lend lend) {
		try {
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement("delete from lend where bookId=? and readerId=?");
			ps.setString(1, lend.getBookId());
			ps.setString(2, lend.getReaderId());
			ps.executeUpdate();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
	}
 
	public Lend selectByBookISBN(String ISBN) {
		try {
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement("select * from lend where ISBN=?");
			ps.setString(1, ISBN);
			rs = ps.executeQuery();
			if (rs.next()) {
				Lend lend = new Lend();
				lend.setBookId(rs.getString(1));
				lend.setReaderId(rs.getString(2));
				lend.setISBN(rs.getString(3));
				lend.setITime(rs.getDate(4));
				return lend;
			} else {
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
	}

	public Lend selectByReaderId(String readerId) {
		try {
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement("select * from lend where readerId=?");
			ps.setString(1, readerId);
			rs = ps.executeQuery();
			if (rs.next()) {
				Lend lend = new Lend();
				lend.setBookId(rs.getString(1));
				lend.setReaderId(rs.getString(2));
				lend.setISBN(rs.getString(3));
				lend.setITime(rs.getDate(4));
				return lend;
			} else
				return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
	}

}
