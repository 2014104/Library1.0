package cn.edu.cdu.ftsoft.model;

import java.util.Date;

public class Lend {
	private String readerId;
	private String bookId;
	private String bookName;
	private String publisher;
	private String ISBN;
	private float price;//�۸�
	private Date ITime;//��������
	public String getReaderId() {
		return readerId;
	}
	public void setReaderId(String readerId) {
		this.readerId = readerId;
	}
	public String getBookId() {
		return bookId;
	}
	public void setBookId(String bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getISBN() {
		return ISBN;
	}
	public void setISBN(String iSBN) {
		ISBN = iSBN;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public Date getITime() {
		return ITime;
	}
	public void setITime(Date iTime) {
		ITime = iTime;
	}
	
	

}
