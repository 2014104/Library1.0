package cn.edu.cdu.ftsoft.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.Test;

import cn.edu.cdu.ftsoft.dao.BookDao;
import cn.edu.cdu.ftsoft.dao.LendDao;
import cn.edu.cdu.ftsoft.dao.ReaderDao;
import cn.edu.cdu.ftsoft.daoImpl.BookDaoImpl;
import cn.edu.cdu.ftsoft.model.Book;
import cn.edu.cdu.ftsoft.model.Lend;
import cn.edu.cdu.ftsoft.model.Reader;

public class TestBookDao {
	private BookDaoImpl bd=new BookDao();
	//@Test
	public void testAddBook(){
		Book book=new Book();
		book.setBookId("333");
		book.setBookName("������");
		book.setISBN("332");
		bd.addBook(book);
	}
	//@Test
	public void testSelectBook(){;
		Book book=bd.selectBook("333");
		System.out.println(book.getBookName());
	}
	//@Test
	public void testSelectLend() {
		try {
			List re=bd.selectAllBook(2, 3);
			for(int i=0;i<re.size();i++){
				Book b=(Book) re.get(i);
				System.out.println(b.getBookId()+","+b.getISBN()+","+b.getPrice()+","+b.getCnum());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testSelectBooks() {
		try {
			List re=bd.selectBooks("", "�����", "", "", "", "", "");
			if(re==null){
				return;
			}
			for(int i=0;i<re.size();i++){
				Book b=(Book) re.get(i);
				System.out.println(b.getBookId()+","+b.getBookName()+","+b.getPrice()+","+b.getCnum());
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
