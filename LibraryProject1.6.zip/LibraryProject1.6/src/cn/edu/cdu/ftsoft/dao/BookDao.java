package cn.edu.cdu.ftsoft.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import cn.edu.cdu.ftsoft.daoImpl.BookDaoImpl;
import cn.edu.cdu.ftsoft.model.Book;
import cn.edu.cdu.ftsoft.model.Lend;
import cn.edu.cdu.ftsoft.util.C3P0Util;

public class BookDao implements BookDaoImpl {
	Connection conn = null;
	PreparedStatement ps = null;
	ResultSet rs = null;

	public Book selectBook(String bookId) {
		try {
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement("select * from book where bookId=?");
			ps.setString(1, bookId);
			rs = ps.executeQuery();
			if (rs.next()) {
				Book book = new Book();
				book.setBookId(rs.getString(1));
				book.setBookName(rs.getString(2));
				book.setISBN(rs.getString(3));
				book.setAuthor(rs.getString(4));
				book.setPublisher(rs.getString(5));
				book.setCnum(rs.getInt(6));
				book.setTypeName(rs.getString(7));
				book.setPhoto(rs.getString(8));
				book.setPrice(rs.getFloat(9));
				return book;
			} else
				return null;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
	}

	public boolean updateBook(Book book) {
		try {
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement("update book set cnum=? where bookId=?");
			ps.setInt(1, book.getCnum());
			ps.setString(2, book.getBookId());
			System.out.println(book.getCnum());
			ps.executeUpdate();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			C3P0Util.release(conn, ps, null);
		}
	}

	public boolean addBook(Book book) {
		try {
			conn = C3P0Util.getConnection();
			ps = conn
					.prepareStatement("insert into book values(?,?,?,?,?,?,?,?,?)");
			ps.setString(1, book.getBookId());
			ps.setString(2, book.getBookName());
			ps.setString(3, book.getISBN());
			ps.setString(4, book.getAuthor());
			ps.setString(5, book.getPublisher());
			ps.setInt(6, book.getCnum());
			ps.setString(7, book.getTypeName());
			ps.setString(8, book.getPhoto());
			ps.setFloat(9, book.getPrice());
			ps.executeUpdate();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			C3P0Util.release(conn, ps, null);
		}
	}

	public boolean deleteBook(String bookId) {
		try {
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement("delete from book where bookId=?");
			ps.setString(1, bookId);
			ps.executeUpdate();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			C3P0Util.release(conn, ps, null);
		}
	}

	public List selectAllBook(int pageNow, int pageSize) {
		try {
			List list = new ArrayList();
			conn = C3P0Util.getConnection();
			String sql = "select * from book limit ?,?";
			ps = conn.prepareStatement(sql);
			ps.setInt(1, (pageNow - 1) * pageSize);
			ps.setInt(2, pageSize);
			rs = ps.executeQuery();
			while (rs.next()) {
				Book book = new Book();
				book.setBookId(rs.getString("bookId"));
				book.setISBN(rs.getString("ISBN"));
				book.setBookName(rs.getString("bookName"));
				book.setTypeName(rs.getString("typeName"));
				book.setPublisher(rs.getString("publisher"));
				book.setPrice(rs.getFloat("price"));
				book.setCnum(rs.getInt("cnum"));
				list.add(book);
			}
			return list;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
	}

	public int selectLendSize() {
		try {
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement("select count(*) from book");	
			rs = ps.executeQuery();
			if (rs.next()) {
				int pageCount = rs.getInt(1);
				return pageCount;
			}
			return 0;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
	}

	public List selectBooks(String bookId, String bookName, String typeName,String minCnum,
			String maxCnum, String minPrice, String maxPrice) {
		String sql = "select * from book where 1=1";
		List list = new ArrayList();
		if(!"".equals(bookId.trim())){
			sql+=" and bookId like ?"; //  ��������д%   %'1002'%
			list.add("%"+bookId.trim()+"%");// '%1002%'
		}
		
		if(!"".equals(typeName.trim())){
			sql+=" and typeName=?";
			list.add(typeName.trim());
		}
		
		if(!"".equals(bookName.trim())){
			sql+=" and bookName like ?";
			list.add("%"+bookName.trim()+"%");
		}
		
		if(!"".equals(minCnum.trim())){
			sql+=" and cnum>?";
			list.add(minCnum);
		}
		if(!"".equals(maxCnum.trim())){
			sql+=" and cnum< ?";
			list.add(maxCnum);
		}
		if(!"".equals(minPrice.trim())){
			sql+=" and price>?";
			list.add(minPrice.trim());
		}
		if(!"".equals(maxPrice.trim())){
			sql+=" and price< ?";
			list.add(maxPrice);
		}
		try {
			List bookList=new ArrayList();
			conn = C3P0Util.getConnection();
			ps = conn.prepareStatement(sql);
			//System.out.println("sql="+sql);
			for(int i=0;i<list.size();i++){
				ps.setString(i+1,(String) list.get(i));
			}
			rs=ps.executeQuery();
			while (rs.next()) {
				Book book = new Book();
				book.setBookId(rs.getString("bookId"));
				book.setISBN(rs.getString("ISBN"));
				book.setBookName(rs.getString("bookName"));
				book.setTypeName(rs.getString("typeName"));
				book.setPublisher(rs.getString("publisher"));
				book.setPrice(rs.getFloat("price"));
				book.setCnum(rs.getInt("cnum"));
				bookList.add(book);
			}
			return bookList;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			C3P0Util.release(conn, ps, rs);
		}
		
	}
}
