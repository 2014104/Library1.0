package cn.edu.cdu.ftsoft.action;

import java.util.List;
import java.util.Map;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts2.ServletActionContext;

import cn.edu.cdu.ftsoft.dao.BookDao;
import cn.edu.cdu.ftsoft.dao.LendDao;
import cn.edu.cdu.ftsoft.daoImpl.BookDaoImpl;
import cn.edu.cdu.ftsoft.daoImpl.LendDaoImpl;
import cn.edu.cdu.ftsoft.model.Book;
import cn.edu.cdu.ftsoft.util.Pager;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;
public class BookAction extends ActionSupport{
	    private BookDaoImpl bookDao=new BookDao();
		private String message;
		private int pageNow=1;   				 //��ʼҳ��Ϊ��һҳ
		private int pageSize=4;   				 //ÿҳ��ʾ4����¼
		private String minCnum;
		private String maxCnum;
		private String minPrice;
		private String maxPrice;
		private Book book;
		private String bookId;
		public String bookList() throws Exception{
			List bookList=bookDao.selectAllBook(pageNow,pageSize);
			Map request=(Map) ActionContext.getContext().get("request");
			Pager page=new Pager(pageNow,bookDao.selectLendSize());
			request.put("bookList", bookList);
			request.put("page", page);
			return SUCCESS;
		}
		public String addBook() throws Exception{
			Book bo=bookDao.selectBook(book.getBookId());
			if(bo!=null){              	 	//�ж�Ҫ���ӵ�ͼ���Ƿ��Ѿ�����
				this.setMessage("ISBN�Ѿ����ڣ�");
				return SUCCESS;
			}
			/*Book b=new Book();
			b.setISBN(book.getISBN());
			b.setBookName(book.getBookName());
			b.setAuthor(book.getAuthor());
			b.setPublisher(book.getPublisher());
			b.setPrice(book.getPrice());
			b.setCnum(book.getCnum());*/
			bookDao.addBook(book);
			this.setMessage("���ӳɹ���");
			return SUCCESS;
		}
		
		public String deleteBook() throws Exception{
			LendDaoImpl lendDao=new LendDao();
			if(lendDao.selectByBookId(bookId)!=null){
				this.setMessage("��ͼ���Ѿ������,����ɾ��");
				return SUCCESS;
			}
			Book bo=bookDao.selectBook(bookId);
			if(bo==null){             //�����ж��Ƿ���ڸ�ͼ��
				this.setMessage("Ҫɾ����ͼ�鲻���ڣ�");
				return SUCCESS;
			}
			bookDao.deleteBook(bookId);
			this.setMessage("ɾ���ɹ���");
			return SUCCESS;
		}

		public String selectPointBook() throws Exception{
			List bookList=bookDao.selectBooks(book.getBookId(),book.getBookName(),book.getTypeName(),minCnum,maxCnum,minPrice,maxPrice);
			//System.out.println("******"+book.getBookId()+","+book.getBookName()+","+book.getTypeName());
			if(bookList==null){
				this.setMessage("��������Щ�����ͼ�飡");
				return SUCCESS;
			}
			Map request=(Map) ActionContext.getContext().get("request");
			if(message!=null){
				request.put("message", message);
			}
			request.put("bookList", bookList);
			return SUCCESS;
		}


		public String updateBook() throws Exception{
			Book b=bookDao.selectBook(book.getBookId());
			if(b==null){
				this.setMessage("Ҫ�޸ĵ�ͼ�鲻����,���Ȳ鿴�Ƿ���ڸ�ͼ�飡");
				return SUCCESS;
			}
			b.setISBN(book.getISBN());
			b.setBookName(book.getBookName());
			b.setAuthor(book.getAuthor());
			b.setPublisher(book.getPublisher());
			b.setPrice(book.getPrice());
			b.setCnum(book.getCnum());
			bookDao.updateBook(b);
			this.setMessage("�޸ĳɹ���");
			return SUCCESS;
		}
		public String getMessage(){
			return this.message;
		}
		public void setMessage(String message){
			this.message = message;
		}
		
		public Book getBook(){
			return book;
		}
		public void setBook(Book book){
			this.book = book;
		}
		public int getPageNow() {
			return pageNow;
		}
		public void setPageNow(int pageNow) {
			this.pageNow = pageNow;
		}
		public int getPageSize() {
			return pageSize;
		}
		public void setPageSize(int pageSize) {
			this.pageSize = pageSize;
		}
		public BookDaoImpl getBookDao() {
			return bookDao;
		}
		public void setBookDao(BookDaoImpl bookDao) {
			this.bookDao = bookDao;
		}
		public String getMinCnum() {
			return minCnum;
		}
		public void setMinCnum(String minCnum) {
			this.minCnum = minCnum;
		}
		public String getMaxCnum() {
			return maxCnum;
		}
		public void setMaxCnum(String maxCnum) {
			this.maxCnum = maxCnum;
		}
		public String getMinPrice() {
			return minPrice;
		}
		public void setMinPrice(String minPrice) {
			this.minPrice = minPrice;
		}
		public String getMaxPrice() {
			return maxPrice;
		}
		public void setMaxPrice(String maxPrice) {
			this.maxPrice = maxPrice;
		}
		public String getBookId() {
			return bookId;
		}
		public void setBookId(String bookId) {
			this.bookId = bookId;
		}
}
