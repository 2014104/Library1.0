package cn.edu.cdu.ftsoft.action;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import cn.edu.cdu.ftsoft.dao.ReaderDao;
import cn.edu.cdu.ftsoft.model.Reader;

import com.opensymphony.xwork2.ActionContext;
import com.opensymphony.xwork2.ActionSupport;


public class LogoutAction extends ActionSupport{
	public String logout(){
		HttpServletRequest request=ServletActionContext.getRequest();
		request.getSession().invalidate();//ʵ���ϵ��õ���session�����е�destroy����
		return INPUT;
	}
}
