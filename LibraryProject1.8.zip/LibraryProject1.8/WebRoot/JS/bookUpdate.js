    function addBook() {
		window.location.href = "add.jsp";
	}