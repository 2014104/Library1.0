package cn.edu.cdu.ftsoft.test;

import static org.junit.Assert.*;

import org.junit.Test;

import cn.edu.cdu.ftsoft.dao.ReaderDao;
import cn.edu.cdu.ftsoft.model.Reader;

public class ReaderDaoTest {

	//@Test
	public void testCheckByReaderIdPas() {
		ReaderDao rd=new ReaderDao();
		try {
			Reader re=rd.checkByReaderIdPas("0006", "11");
			System.out.print(re.getPassword());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//@Test
	public void testCheckByReaderId() {
		ReaderDao rd=new ReaderDao();
		try {
			Reader re=rd.checkByReaderId("0006");
			System.out.print(re.getPassword()+","+re.getName()+","+re.getNum());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@Test
	public void testUpdateReader() {
		ReaderDao rd=new ReaderDao();
		Reader r=new Reader();
		r.setNum(1);
		r.setReaderId("0006");
		try {
			rd.updateReader(r);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
